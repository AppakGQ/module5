using ProductClient.Models;
namespace ProductClient.Services;
public interface IProductApiService
{
    Task<List<Product>> GetAllAsync();
    Task<Product?> GetByIdAsync(int id);
    Task<HttpResponseMessage> CreateAsync(Product item);
    Task<HttpResponseMessage> UpdateAsync(int id, Product item);
    Task<HttpResponseMessage> DeleteAsync(int id);
}
