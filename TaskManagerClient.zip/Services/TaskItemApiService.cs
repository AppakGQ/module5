using System.Net;
using System.Net.Http.Json;
using TaskManagerClient.Models;
namespace TaskManagerClient.Services;
public class TaskItemApiService : ITaskItemApiService
{
    private readonly HttpClient _http;
    public TaskItemApiService(IHttpClientFactory factory) => _http = factory.CreateClient("TaskItemApi");
    public async Task<List<TaskItem>> GetAllAsync() => await _http.GetFromJsonAsync<List<TaskItem>>("api/tasks") ?? new();
    public async Task<TaskItem?> GetByIdAsync(int id)
    {
        var response = await _http.GetAsync($"api/tasks/{id}");
        return response.StatusCode == HttpStatusCode.NotFound ? null : response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<TaskItem>() : throw new HttpRequestException($"Ошибка API: {(int)response.StatusCode}");
    }
    public Task<HttpResponseMessage> CreateAsync(TaskItem item) => _http.PostAsJsonAsync("api/tasks", item);
    public Task<HttpResponseMessage> UpdateAsync(int id, TaskItem item) => _http.PutAsJsonAsync($"api/tasks/{id}", item);
    public Task<HttpResponseMessage> DeleteAsync(int id) => _http.DeleteAsync($"api/tasks/{id}");
}
