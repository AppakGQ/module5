using TaskManagerClient.Models;
using TaskManagerClient.Services;
using System.Collections.Concurrent;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<DemoStore>();
builder.Services.AddHttpClient("TaskItemApi", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Api:BaseAddress"]!);
});
builder.Services.AddScoped<ITaskItemApiService, TaskItemApiService>();
var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=TaskItem}/{action=Index}/{id?}");
app.MapGet("/api/tasks", (DemoStore store) => Results.Ok(store.All()));
app.MapGet("/api/tasks/{id:int}", (int id, DemoStore store) =>
{
    var item = store.Find(id);
    return item is null ? Results.NotFound() : Results.Ok(item);
});
app.MapPost("/api/tasks", ( TaskItem item, DemoStore store) =>
{
    var created = store.Add(item);
    return Results.Created($"/api/tasks/{created.Id}", created);
});
app.MapPut("/api/tasks/{id:int}", (int id, TaskItem item, DemoStore store) =>
{
    var updated = store.Update(id, item);
    return updated is null ? Results.NotFound() : Results.Ok(updated);
});
app.MapDelete("/api/tasks/{id:int}", (int id, DemoStore store) =>
    store.Remove(id) ? Results.NoContent() : Results.NotFound());
app.Run();

public sealed class DemoStore
{
    private readonly ConcurrentDictionary<int, TaskItem> _items = new();
    private int _nextId = 4;
    public DemoStore()
    {
        _items[1] = new TaskItem { Title = "Изучить HttpClient", Description = "Разобрать работу HttpClient", IsCompleted = true };
        _items[2] = new TaskItem { Title = "Реализовать Web API", Description = "Создать клиент для API", IsCompleted = false };
        _items[3] = new TaskItem { Title = "Изучить PATCH", Description = "Изучить частичное обновление", IsCompleted = false };
    }
    public List<TaskItem> All() => _items.Values.OrderBy(x => x.Id).ToList();
    public TaskItem? Find(int id) => _items.GetValueOrDefault(id);
    public TaskItem Add(TaskItem item) { item.Id = Interlocked.Increment(ref _nextId)-1; _items[item.Id] = item; return item; }
    public TaskItem? Update(int id, TaskItem item) { if (!_items.ContainsKey(id)) return null; item.Id=id; _items[id]=item; return item; }
    public bool Remove(int id) => _items.TryRemove(id, out _);
}
