using System.Net;
using System.Net.Http.Json;
using ProductClient.Models;
namespace ProductClient.Services;
public class ProductApiService : IProductApiService
{
    private readonly HttpClient _http;
    public ProductApiService(IHttpClientFactory factory) => _http = factory.CreateClient("ProductApi");
    public async Task<List<Product>> GetAllAsync() => await _http.GetFromJsonAsync<List<Product>>("api/products") ?? new();
    public async Task<Product?> GetByIdAsync(int id)
    {
        var response = await _http.GetAsync($"api/products/{id}");
        return response.StatusCode == HttpStatusCode.NotFound ? null : response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<Product>() : throw new HttpRequestException($"Ошибка API: {(int)response.StatusCode}");
    }
    public Task<HttpResponseMessage> CreateAsync(Product item) => _http.PostAsJsonAsync("api/products", item);
    public Task<HttpResponseMessage> UpdateAsync(int id, Product item) => _http.PutAsJsonAsync($"api/products/{id}", item);
    public Task<HttpResponseMessage> DeleteAsync(int id) => _http.DeleteAsync($"api/products/{id}");
}
