using ProductClient.Models;
using ProductClient.Services;
using System.Collections.Concurrent;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<DemoStore>();
builder.Services.AddHttpClient("ProductApi", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Api:BaseAddress"]!);
});
builder.Services.AddScoped<IProductApiService, ProductApiService>();
var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=Product}/{action=Index}/{id?}");
app.MapGet("/api/products", (DemoStore store) => Results.Ok(store.All()));
app.MapGet("/api/products/{id:int}", (int id, DemoStore store) =>
{
    var item = store.Find(id);
    return item is null ? Results.NotFound() : Results.Ok(item);
});
app.MapPost("/api/products", ( Product item, DemoStore store) =>
{
    var created = store.Add(item);
    return Results.Created($"/api/products/{created.Id}", created);
});
app.MapPut("/api/products/{id:int}", (int id, Product item, DemoStore store) =>
{
    var updated = store.Update(id, item);
    return updated is null ? Results.NotFound() : Results.Ok(updated);
});
app.MapDelete("/api/products/{id:int}", (int id, DemoStore store) =>
    store.Remove(id) ? Results.NoContent() : Results.NotFound());
app.Run();

public sealed class DemoStore
{
    private readonly ConcurrentDictionary<int, Product> _items = new();
    private int _nextId = 4;
    public DemoStore()
    {
        _items[1] = new Product { Name = "Notebook", Description = "Рабочий ноутбук", Price = 350000, Quantity = 5 };
        _items[2] = new Product { Name = "Mouse", Description = "Беспроводная мышь", Price = 8000, Quantity = 15 };
        _items[3] = new Product { Name = "Keyboard", Description = "Механическая клавиатура", Price = 15000, Quantity = 10 };
    }
    public List<Product> All() => _items.Values.OrderBy(x => x.Id).ToList();
    public Product? Find(int id) => _items.GetValueOrDefault(id);
    public Product Add(Product item) { item.Id = Interlocked.Increment(ref _nextId)-1; _items[item.Id] = item; return item; }
    public Product? Update(int id, Product item) { if (!_items.ContainsKey(id)) return null; item.Id=id; _items[id]=item; return item; }
    public bool Remove(int id) => _items.TryRemove(id, out _);
}
