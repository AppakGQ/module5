using System.ComponentModel.DataAnnotations;
namespace StudentClient.Models;
public class Student
{
    public int Id { get; set; }
    [Required]
    public string FullName { get; set; } = string.Empty;
    [Required]
    public string Group { get; set; } = string.Empty;
    [Required]
    public int Course { get; set; }
    [Required]
    public string Email { get; set; } = string.Empty;
}
