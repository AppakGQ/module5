using Microsoft.AspNetCore.Mvc;
using StudentClient.Models;
using StudentClient.Services;
namespace StudentClient.Controllers;
public class StudentController : Controller
{
    private readonly IStudentApiService _api;
    public StudentController(IStudentApiService api) => _api=api;
    public async Task<IActionResult> Index() { try { return View(await _api.GetAllAsync()); } catch { ViewBag.Error="Не удалось подключиться к Web API. Проверьте адрес сервера."; return View(new List<Student>()); } }
    public async Task<IActionResult> Details(int id) { try { var item=await _api.GetByIdAsync(id); if(item is null) { ViewBag.Error="Студент с указанным ID не найден."; return View(); } return View(item); } catch { ViewBag.Error="Ошибка при получении данных."; return View(); } }
    public async Task<IActionResult> Create() => View(new Student());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Student item) { if(!ModelState.IsValid) return View(item); try { using var r=await _api.CreateAsync(item); if(!r.IsSuccessStatusCode) { ModelState.AddModelError("", await ErrorText(r)); return View(item); } return RedirectToAction(nameof(Index)); } catch { ModelState.AddModelError("","Сервер API недоступен."); return View(item); } }
    public async Task<IActionResult> Edit(int id) { try { var item=await _api.GetByIdAsync(id); return item is null ? NotFound() : View(item); } catch { return RedirectToAction(nameof(Index)); } }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Student item) { if(id!=item.Id) return BadRequest(); if(!ModelState.IsValid) return View(item); try { using var r=await _api.UpdateAsync(id,item); if(!r.IsSuccessStatusCode) { ModelState.AddModelError("",await ErrorText(r)); return View(item); } return RedirectToAction(nameof(Index)); } catch { ModelState.AddModelError("","Сервер API недоступен."); return View(item); } }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) { try { using var r=await _api.DeleteAsync(id); if(!r.IsSuccessStatusCode && r.StatusCode!=System.Net.HttpStatusCode.NotFound) TempData["Error"]=await ErrorText(r); } catch { TempData["Error"]="Сервер API недоступен."; } return RedirectToAction(nameof(Index)); }
    private static async Task<string> ErrorText(HttpResponseMessage r) => r.StatusCode switch { System.Net.HttpStatusCode.BadRequest=>"Некорректные данные (400).", System.Net.HttpStatusCode.NotFound=>"Запись не найдена (404).", System.Net.HttpStatusCode.InternalServerError=>"Внутренняя ошибка сервера (500).", _=>$"Ошибка API: {(int)r.StatusCode}" };
}
