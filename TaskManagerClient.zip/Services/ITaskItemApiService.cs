using TaskManagerClient.Models;
namespace TaskManagerClient.Services;
public interface ITaskItemApiService
{
    Task<List<TaskItem>> GetAllAsync();
    Task<TaskItem?> GetByIdAsync(int id);
    Task<HttpResponseMessage> CreateAsync(TaskItem item);
    Task<HttpResponseMessage> UpdateAsync(int id, TaskItem item);
    Task<HttpResponseMessage> DeleteAsync(int id);
}
