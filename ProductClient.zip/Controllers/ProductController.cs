using Microsoft.AspNetCore.Mvc;
using ProductClient.Models;
using ProductClient.Services;
namespace ProductClient.Controllers;
public class ProductController : Controller
{
    private readonly IProductApiService _api;
    public ProductController(IProductApiService api) => _api=api;
    public async Task<IActionResult> Index() { try { return View(await _api.GetAllAsync()); } catch { ViewBag.Error="Не удалось подключиться к Web API. Проверьте адрес сервера."; return View(new List<Product>()); } }
    public async Task<IActionResult> Details(int id) { try { var item=await _api.GetByIdAsync(id); if(item is null) { ViewBag.Error="Товар не найден."; return View(); } return View(item); } catch { ViewBag.Error="Ошибка при получении данных."; return View(); } }
    public async Task<IActionResult> Create() => View(new Product());
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Product item) { if(!ModelState.IsValid) return View(item); try { using var r=await _api.CreateAsync(item); if(!r.IsSuccessStatusCode) { ModelState.AddModelError("", await ErrorText(r)); return View(item); } return RedirectToAction(nameof(Index)); } catch { ModelState.AddModelError("","Сервер API недоступен."); return View(item); } }
    public async Task<IActionResult> Edit(int id) { try { var item=await _api.GetByIdAsync(id); return item is null ? NotFound() : View(item); } catch { return RedirectToAction(nameof(Index)); } }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(int id, Product item) { if(id!=item.Id) return BadRequest(); if(!ModelState.IsValid) return View(item); try { using var r=await _api.UpdateAsync(id,item); if(!r.IsSuccessStatusCode) { ModelState.AddModelError("",await ErrorText(r)); return View(item); } return RedirectToAction(nameof(Index)); } catch { ModelState.AddModelError("","Сервер API недоступен."); return View(item); } }
    [HttpPost, ValidateAntiForgeryToken]
    public async Task<IActionResult> Delete(int id) { try { using var r=await _api.DeleteAsync(id); if(!r.IsSuccessStatusCode && r.StatusCode!=System.Net.HttpStatusCode.NotFound) TempData["Error"]=await ErrorText(r); } catch { TempData["Error"]="Сервер API недоступен."; } return RedirectToAction(nameof(Index)); }
    private static async Task<string> ErrorText(HttpResponseMessage r) => r.StatusCode switch { System.Net.HttpStatusCode.BadRequest=>"Некорректные данные (400).", System.Net.HttpStatusCode.NotFound=>"Запись не найдена (404).", System.Net.HttpStatusCode.InternalServerError=>"Внутренняя ошибка сервера (500).", _=>$"Ошибка API: {(int)r.StatusCode}" };
}
