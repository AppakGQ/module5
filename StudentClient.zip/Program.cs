using StudentClient.Models;
using StudentClient.Services;
using System.Collections.Concurrent;
using System.Net;

var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
builder.Services.AddSingleton<DemoStore>();
builder.Services.AddHttpClient("StudentApi", client =>
{
    client.BaseAddress = new Uri(builder.Configuration["Api:BaseAddress"]!);
});
builder.Services.AddScoped<IStudentApiService, StudentApiService>();
var app = builder.Build();
app.UseStaticFiles();
app.UseRouting();
app.MapControllerRoute(name: "default", pattern: "{controller=Student}/{action=Index}/{id?}");
app.MapGet("/api/students", (DemoStore store) => Results.Ok(store.All()));
app.MapGet("/api/students/{id:int}", (int id, DemoStore store) =>
{
    var item = store.Find(id);
    return item is null ? Results.NotFound() : Results.Ok(item);
});
app.MapPost("/api/students", ( Student item, DemoStore store) =>
{
    var created = store.Add(item);
    return Results.Created($"/api/students/{created.Id}", created);
});
app.MapPut("/api/students/{id:int}", (int id, Student item, DemoStore store) =>
{
    var updated = store.Update(id, item);
    return updated is null ? Results.NotFound() : Results.Ok(updated);
});
app.MapDelete("/api/students/{id:int}", (int id, DemoStore store) =>
    store.Remove(id) ? Results.NoContent() : Results.NotFound());
app.Run();

public sealed class DemoStore
{
    private readonly ConcurrentDictionary<int, Student> _items = new();
    private int _nextId = 4;
    public DemoStore()
    {
        _items[1] = new Student { FullName = "Иван Иванов", Group = "SE-301", Course = 3, Email = "ivan@example.com" };
        _items[2] = new Student { FullName = "Анна Петрова", Group = "SE-302", Course = 3, Email = "anna@example.com" };
        _items[3] = new Student { FullName = "Максим Ким", Group = "SE-301", Course = 3, Email = "maxim@example.com" };
    }
    public List<Student> All() => _items.Values.OrderBy(x => x.Id).ToList();
    public Student? Find(int id) => _items.GetValueOrDefault(id);
    public Student Add(Student item) { item.Id = Interlocked.Increment(ref _nextId)-1; _items[item.Id] = item; return item; }
    public Student? Update(int id, Student item) { if (!_items.ContainsKey(id)) return null; item.Id=id; _items[id]=item; return item; }
    public bool Remove(int id) => _items.TryRemove(id, out _);
}
