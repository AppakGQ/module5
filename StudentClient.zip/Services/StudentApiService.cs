using System.Net;
using System.Net.Http.Json;
using StudentClient.Models;
namespace StudentClient.Services;
public class StudentApiService : IStudentApiService
{
    private readonly HttpClient _http;
    public StudentApiService(IHttpClientFactory factory) => _http = factory.CreateClient("StudentApi");
    public async Task<List<Student>> GetAllAsync() => await _http.GetFromJsonAsync<List<Student>>("api/students") ?? new();
    public async Task<Student?> GetByIdAsync(int id)
    {
        var response = await _http.GetAsync($"api/students/{id}");
        return response.StatusCode == HttpStatusCode.NotFound ? null : response.IsSuccessStatusCode ? await response.Content.ReadFromJsonAsync<Student>() : throw new HttpRequestException($"Ошибка API: {(int)response.StatusCode}");
    }
    public Task<HttpResponseMessage> CreateAsync(Student item) => _http.PostAsJsonAsync("api/students", item);
    public Task<HttpResponseMessage> UpdateAsync(int id, Student item) => _http.PutAsJsonAsync($"api/students/{id}", item);
    public Task<HttpResponseMessage> DeleteAsync(int id) => _http.DeleteAsync($"api/students/{id}");
}
