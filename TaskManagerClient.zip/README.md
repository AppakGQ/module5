# TaskManagerClient

ASP.NET Core MVC клиент для работы с taskitem через именованный HttpClient и IHttpClientFactory. В проект встроен демонстрационный Web API с начальными данными, поэтому приложение запускается самостоятельно.

Адрес Web API: `http://localhost:5080/api/tasks`

Реализованы методы GET (список и запись), POST, PUT и DELETE. Ответы 200, 201, 400, 404 и 500 обрабатываются; при удалении запрашивается подтверждение.

`IHttpClientFactory` регистрируется в `Program.cs` через `AddHttpClient`, а сервис получает именованный клиент через `CreateClient`.

Запуск: `dotnet restore`, затем `dotnet run --urls http://localhost:5080`.
