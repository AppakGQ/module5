using StudentClient.Models;
namespace StudentClient.Services;
public interface IStudentApiService
{
    Task<List<Student>> GetAllAsync();
    Task<Student?> GetByIdAsync(int id);
    Task<HttpResponseMessage> CreateAsync(Student item);
    Task<HttpResponseMessage> UpdateAsync(int id, Student item);
    Task<HttpResponseMessage> DeleteAsync(int id);
}
